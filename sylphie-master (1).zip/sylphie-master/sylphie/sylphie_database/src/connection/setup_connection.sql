PRAGMA journal_mode = wal;
PRAGMA foreign_keys = true;
PRAGMA busy_timeout = 5000;
